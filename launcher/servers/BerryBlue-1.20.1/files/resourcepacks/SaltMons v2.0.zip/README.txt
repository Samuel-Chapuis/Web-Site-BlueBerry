Base Rotom's Model is heavily inspired by Requin's (@itzrequin) base Rotom model! Melmetal's Model is heavily inspired by The_Ace_Defective (@the_ace_defectives) and 8BallBoi123 (@8ballboi123). Show them some love and support, they're very talented!

To SpencyRock (@spencyrock) on Discord, you have permission to use this in UltiMon if you choose to do so.


-----
I'm  not good at solving issues related to JSON if the datapack does not work on your end. If there are any moves missing from a Pokemon, please let me know!
